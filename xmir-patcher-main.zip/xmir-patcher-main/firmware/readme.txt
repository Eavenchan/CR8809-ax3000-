In this folder, you should put the firmware for flashing.
